package com.dicoding.github.ui

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.github.R
import com.dicoding.github.data.response.ResponseUser
import com.dicoding.github.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "DetailActivity"
        const val EXTRA_NAME = "extra_name"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userName = intent.getStringExtra(EXTRA_NAME).toString()

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = userName
        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs


        TabLayoutMediator(tabs, viewPager){ tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

        detailViewModel.showDetailUser(userName)

        detailViewModel.detailUser.observe(this){
            setDetailData(it)
        }

        detailViewModel.isLoading.observe(this){
            showLoading(it)
        }


    }


    private fun setDetailData(userDetail: ResponseUser) {

        binding.tvUsername.text = userDetail.login
        binding.tvName.text = userDetail.name ?: "Not Name"
        binding.tvFollowersCount.text = getString(R.string._500_followers, userDetail.followers)
        binding.tvFollowingCount.text = getString(R.string._500_followers, userDetail.following)

        Glide.with(this@DetailActivity)
            .load(userDetail.avatarUrl)
            .into(binding.ivAvatar)
    }


    private fun showLoading(isLoading: Boolean) {
        if (isLoading){
            binding.progressBar.visibility = View.VISIBLE
        } else{
            binding.progressBar.visibility = View.GONE
        }
    }
}